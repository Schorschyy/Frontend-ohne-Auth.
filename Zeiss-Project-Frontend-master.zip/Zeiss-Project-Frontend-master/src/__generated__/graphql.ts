/* eslint-disable */
import type { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core';
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
  /** The `Long` scalar type represents non-fractional signed whole 64-bit numeric values. Long can represent values between -(2^63) and 2^63 - 1. */
  Long: any;
};

export enum Action {
  Create = 'CREATE',
  Delete = 'DELETE',
  Update = 'UPDATE'
}

export type AddExpertPayload = {
  __typename?: 'AddExpertPayload';
  expert?: Maybe<Expert>;
};

export enum ApplyPolicy {
  AfterResolver = 'AFTER_RESOLVER',
  BeforeResolver = 'BEFORE_RESOLVER',
  Validation = 'VALIDATION'
}

export type Error = {
  message: Scalars['String'];
};

export type Expert = Node & {
  __typename?: 'Expert';
  email?: Maybe<Scalars['String']>;
  headExpert?: Maybe<Expert>;
  headExpertId?: Maybe<Scalars['String']>;
  id: Scalars['ID'];
  name?: Maybe<Scalars['String']>;
  skills: Array<Skill>;
  teamMembers: Array<Expert>;
};

export type ExpertFilterInput = {
  and?: InputMaybe<Array<ExpertFilterInput>>;
  expertSkills?: InputMaybe<ListFilterInputTypeOfExpertSkillFilterInput>;
  headExpert?: InputMaybe<ExpertFilterInput>;
  headExpertId?: InputMaybe<StringOperationFilterInput>;
  id?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ExpertFilterInput>>;
  teamMembers?: InputMaybe<ListFilterInputTypeOfExpertFilterInput>;
};

export type ExpertNotFoundError = Error & {
  __typename?: 'ExpertNotFoundError';
  message: Scalars['String'];
};

export type ExpertSkill = {
  __typename?: 'ExpertSkill';
  expert: Expert;
  expertId: Scalars['String'];
  level: Scalars['Int'];
  skill: Skill;
  skillId: Scalars['Long'];
};

export type ExpertSkillFilterInput = {
  and?: InputMaybe<Array<ExpertSkillFilterInput>>;
  expert?: InputMaybe<ExpertFilterInput>;
  expertId?: InputMaybe<StringOperationFilterInput>;
  level?: InputMaybe<IntOperationFilterInput>;
  or?: InputMaybe<Array<ExpertSkillFilterInput>>;
  skill?: InputMaybe<SkillFilterInput>;
  skillId?: InputMaybe<LongOperationFilterInput>;
};

/** A connection to a list of items. */
export type ExpertsConnection = {
  __typename?: 'ExpertsConnection';
  /** A list of edges. */
  edges?: Maybe<Array<ExpertsEdge>>;
  /** A flattened list of the nodes. */
  nodes?: Maybe<Array<Expert>>;
  /** Information to aid in pagination. */
  pageInfo: PageInfo;
};

/** An edge in a connection. */
export type ExpertsEdge = {
  __typename?: 'ExpertsEdge';
  /** A cursor for use in pagination. */
  cursor: Scalars['String'];
  /** The item at the end of the edge. */
  node: Expert;
};

export type IdOperationFilterInput = {
  eq?: InputMaybe<Scalars['ID']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['ID']>>>;
  neq?: InputMaybe<Scalars['ID']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['ID']>>>;
};

export type IntOperationFilterInput = {
  eq?: InputMaybe<Scalars['Int']>;
  gt?: InputMaybe<Scalars['Int']>;
  gte?: InputMaybe<Scalars['Int']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['Int']>>>;
  lt?: InputMaybe<Scalars['Int']>;
  lte?: InputMaybe<Scalars['Int']>;
  neq?: InputMaybe<Scalars['Int']>;
  ngt?: InputMaybe<Scalars['Int']>;
  ngte?: InputMaybe<Scalars['Int']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['Int']>>>;
  nlt?: InputMaybe<Scalars['Int']>;
  nlte?: InputMaybe<Scalars['Int']>;
};

export type InvalidSkillUpdateError = Error & {
  __typename?: 'InvalidSkillUpdateError';
  message: Scalars['String'];
};

export type ListFilterInputTypeOfExpertFilterInput = {
  all?: InputMaybe<ExpertFilterInput>;
  any?: InputMaybe<Scalars['Boolean']>;
  none?: InputMaybe<ExpertFilterInput>;
  some?: InputMaybe<ExpertFilterInput>;
};

export type ListFilterInputTypeOfExpertSkillFilterInput = {
  all?: InputMaybe<ExpertSkillFilterInput>;
  any?: InputMaybe<Scalars['Boolean']>;
  none?: InputMaybe<ExpertSkillFilterInput>;
  some?: InputMaybe<ExpertSkillFilterInput>;
};

export type ListFilterInputTypeOfSkillFilterInput = {
  all?: InputMaybe<SkillFilterInput>;
  any?: InputMaybe<Scalars['Boolean']>;
  none?: InputMaybe<SkillFilterInput>;
  some?: InputMaybe<SkillFilterInput>;
};

export type LongOperationFilterInput = {
  eq?: InputMaybe<Scalars['Long']>;
  gt?: InputMaybe<Scalars['Long']>;
  gte?: InputMaybe<Scalars['Long']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['Long']>>>;
  lt?: InputMaybe<Scalars['Long']>;
  lte?: InputMaybe<Scalars['Long']>;
  neq?: InputMaybe<Scalars['Long']>;
  ngt?: InputMaybe<Scalars['Long']>;
  ngte?: InputMaybe<Scalars['Long']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['Long']>>>;
  nlt?: InputMaybe<Scalars['Long']>;
  nlte?: InputMaybe<Scalars['Long']>;
};

export type Mutation = {
  __typename?: 'Mutation';
  addExpert: AddExpertPayload;
  updateExpert: UpdateExpertPayload;
  updateExpertSkills: UpdateExpertSkillsPayload;
  upsertSkills: UpsertSkillsPayload;
};


export type MutationUpdateExpertArgs = {
  input: UpdateExpertInput;
};


export type MutationUpdateExpertSkillsArgs = {
  input: UpdateExpertSkillsInput;
};


export type MutationUpsertSkillsArgs = {
  input: UpsertSkillsInput;
};

/** The node interface is implemented by entities that have a global unique identifier. */
export type Node = {
  id: Scalars['ID'];
};

/** Information about pagination in a connection. */
export type PageInfo = {
  __typename?: 'PageInfo';
  /** When paginating forwards, the cursor to continue. */
  endCursor?: Maybe<Scalars['String']>;
  /** Indicates whether more edges exist following the set defined by the clients arguments. */
  hasNextPage: Scalars['Boolean'];
  /** Indicates whether more edges exist prior the set defined by the clients arguments. */
  hasPreviousPage: Scalars['Boolean'];
  /** When paginating backwards, the cursor to continue. */
  startCursor?: Maybe<Scalars['String']>;
};

export type Query = {
  __typename?: 'Query';
  expertById: Expert;
  experts?: Maybe<ExpertsConnection>;
  me: Expert;
  /** Fetches an object given its ID. */
  node?: Maybe<Node>;
  /** Lookup nodes by a list of IDs. */
  nodes: Array<Maybe<Node>>;
  skillById: Skill;
  skills: Array<Skill>;
};


export type QueryExpertByIdArgs = {
  id: Scalars['ID'];
};


export type QueryExpertsArgs = {
  after?: InputMaybe<Scalars['String']>;
  before?: InputMaybe<Scalars['String']>;
  first?: InputMaybe<Scalars['Int']>;
  last?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ExpertFilterInput>;
};


export type QueryNodeArgs = {
  id: Scalars['ID'];
};


export type QueryNodesArgs = {
  ids: Array<Scalars['ID']>;
};


export type QuerySkillByIdArgs = {
  id: Scalars['ID'];
};


export type QuerySkillsArgs = {
  order?: InputMaybe<Array<SkillSortInput>>;
  where?: InputMaybe<SkillFilterInput>;
};

export type Skill = Node & {
  __typename?: 'Skill';
  childSkills: Array<Skill>;
  expertSkills: Array<ExpertSkill>;
  id: Scalars['ID'];
  name: Scalars['String'];
  parentSkill?: Maybe<Skill>;
  parentSkillId?: Maybe<Scalars['ID']>;
};

export type SkillFilterInput = {
  and?: InputMaybe<Array<SkillFilterInput>>;
  childSkills?: InputMaybe<ListFilterInputTypeOfSkillFilterInput>;
  expertSkills?: InputMaybe<ListFilterInputTypeOfExpertSkillFilterInput>;
  id?: InputMaybe<IdOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<SkillFilterInput>>;
  parentSkill?: InputMaybe<SkillFilterInput>;
  parentSkillId?: InputMaybe<IdOperationFilterInput>;
};

export type SkillNotFoundError = Error & {
  __typename?: 'SkillNotFoundError';
  message: Scalars['String'];
};

export type SkillSortInput = {
  id?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
  parentSkill?: InputMaybe<SkillSortInput>;
  parentSkillId?: InputMaybe<SortEnumType>;
};

export type SkillUpdateInput = {
  name: Scalars['String'];
  /** relay encoded id / invalid reference id none yet stored skill */
  parentSkillReferenceId?: InputMaybe<Scalars['String']>;
  /** relay encoded id / invalid reference id none yet stored skill */
  referenceId: Scalars['String'];
  status: Action;
};

export type SkillUpdateResult = {
  __typename?: 'SkillUpdateResult';
  childSkills: Array<Skill>;
  expertSkills: Array<ExpertSkill>;
  id: Scalars['ID'];
  name: Scalars['String'];
  parentSkill?: Maybe<Skill>;
  parentSkillId?: Maybe<Scalars['ID']>;
  referenceId: Scalars['String'];
};

export enum SortEnumType {
  Asc = 'ASC',
  Desc = 'DESC'
}

export type StringOperationFilterInput = {
  and?: InputMaybe<Array<StringOperationFilterInput>>;
  contains?: InputMaybe<Scalars['String']>;
  endsWith?: InputMaybe<Scalars['String']>;
  eq?: InputMaybe<Scalars['String']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['String']>>>;
  ncontains?: InputMaybe<Scalars['String']>;
  nendsWith?: InputMaybe<Scalars['String']>;
  neq?: InputMaybe<Scalars['String']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['String']>>>;
  nstartsWith?: InputMaybe<Scalars['String']>;
  or?: InputMaybe<Array<StringOperationFilterInput>>;
  startsWith?: InputMaybe<Scalars['String']>;
};

export type UpdateExpertError = ExpertNotFoundError;

export type UpdateExpertInput = {
  id: Scalars['ID'];
};

export type UpdateExpertPayload = {
  __typename?: 'UpdateExpertPayload';
  errors?: Maybe<Array<UpdateExpertError>>;
  expert?: Maybe<Expert>;
};

export type UpdateExpertSkillsError = ExpertNotFoundError | SkillNotFoundError;

export type UpdateExpertSkillsInput = {
  expertId: Scalars['ID'];
  skillIds: Array<Scalars['ID']>;
};

export type UpdateExpertSkillsPayload = {
  __typename?: 'UpdateExpertSkillsPayload';
  errors?: Maybe<Array<UpdateExpertSkillsError>>;
  expert?: Maybe<Expert>;
};

export type UpsertSkillsError = InvalidSkillUpdateError;

export type UpsertSkillsInput = {
  skills: Array<SkillUpdateInput>;
};

export type UpsertSkillsPayload = {
  __typename?: 'UpsertSkillsPayload';
  errors?: Maybe<Array<UpsertSkillsError>>;
  skillUpdateResult?: Maybe<Array<SkillUpdateResult>>;
};

export type GetMeQueryVariables = Exact<{ [key: string]: never; }>;


export type GetMeQuery = { __typename?: 'Query', me: { __typename?: 'Expert', id: string, name?: string | null } };

export type GetExpertsQueryVariables = Exact<{ [key: string]: never; }>;


export type GetExpertsQuery = { __typename?: 'Query', experts?: { __typename?: 'ExpertsConnection', nodes?: Array<{ __typename?: 'Expert', id: string, name?: string | null, skills: Array<{ __typename?: 'Skill', id: string, name: string }> }> | null, edges?: Array<{ __typename?: 'ExpertsEdge', cursor: string }> | null } | null };

export type GetSkillsQueryVariables = Exact<{ [key: string]: never; }>;


export type GetSkillsQuery = { __typename?: 'Query', skills: Array<{ __typename?: 'Skill', name: string, id: string, parentSkillId?: string | null }> };

export type GetSkillQueryVariables = Exact<{
  parent?: InputMaybe<Scalars['ID']>;
}>;


export type GetSkillQuery = { __typename?: 'Query', skills: Array<{ __typename?: 'Skill', id: string, name: string, parentSkillId?: string | null }> };

export type UpsertSkillsMutationVariables = Exact<{
  skills: Array<SkillUpdateInput> | SkillUpdateInput;
}>;


export type UpsertSkillsMutation = { __typename?: 'Mutation', upsertSkills: { __typename?: 'UpsertSkillsPayload', skillUpdateResult?: Array<{ __typename?: 'SkillUpdateResult', referenceId: string, id: string, name: string, parentSkillId?: string | null }> | null, errors?: Array<{ __typename?: 'InvalidSkillUpdateError', message: string, code: 'InvalidSkillUpdateError' }> | null } };


export const GetMeDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"GetMe"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"me"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"name"}}]}}]}}]} as unknown as DocumentNode<GetMeQuery, GetMeQueryVariables>;
export const GetExpertsDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"GetExperts"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"experts"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"nodes"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"skills"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"name"}}]}}]}},{"kind":"Field","name":{"kind":"Name","value":"edges"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"cursor"}}]}}]}}]}}]} as unknown as DocumentNode<GetExpertsQuery, GetExpertsQueryVariables>;
export const GetSkillsDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"GetSkills"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"skills"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"parentSkillId"}}]}}]}}]} as unknown as DocumentNode<GetSkillsQuery, GetSkillsQueryVariables>;
export const GetSkillDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"GetSkill"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"parent"}},"type":{"kind":"NamedType","name":{"kind":"Name","value":"ID"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"skills"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"where"},"value":{"kind":"ObjectValue","fields":[{"kind":"ObjectField","name":{"kind":"Name","value":"parentSkillId"},"value":{"kind":"ObjectValue","fields":[{"kind":"ObjectField","name":{"kind":"Name","value":"eq"},"value":{"kind":"Variable","name":{"kind":"Name","value":"parent"}}}]}}]}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"parentSkillId"}}]}}]}}]} as unknown as DocumentNode<GetSkillQuery, GetSkillQueryVariables>;
export const UpsertSkillsDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"UpsertSkills"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"skills"}},"type":{"kind":"NonNullType","type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"SkillUpdateInput"}}}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"upsertSkills"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"ObjectValue","fields":[{"kind":"ObjectField","name":{"kind":"Name","value":"skills"},"value":{"kind":"Variable","name":{"kind":"Name","value":"skills"}}}]}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"skillUpdateResult"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"referenceId"}},{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"parentSkillId"}}]}},{"kind":"Field","name":{"kind":"Name","value":"errors"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","alias":{"kind":"Name","value":"code"},"name":{"kind":"Name","value":"__typename"}},{"kind":"InlineFragment","typeCondition":{"kind":"NamedType","name":{"kind":"Name","value":"Error"}},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"message"}}]}}]}}]}}]}}]} as unknown as DocumentNode<UpsertSkillsMutation, UpsertSkillsMutationVariables>;