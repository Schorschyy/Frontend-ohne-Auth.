<script setup lang="ts">
import AuthLinks from "@/components/authentication/AuthLinks.vue";
import {useRouter} from "vue-router";
import {RouteMeta} from "@/scripts/config/router";
import {getFlattRoutes} from "@/scripts/services/router/util";

const leftDrawerOpen = ref(false);

const allRoutes = useRouter().options.routes;
const displayRoutes = computed(() => {
  return getFlattRoutes(allRoutes)
      .filter(route => (route.meta as RouteMeta | undefined)?.tab)
      .map(route => ({path: route.path, meta: route.meta as RouteMeta | undefined}))
})
</script>

<template>
  <q-layout view="hhh LpR fFf">
    <q-header reveal elevated class="primary">
      <q-toolbar>
        <q-btn
            dense
            flat
            round
            icon="menu"
            @click="leftDrawerOpen = !leftDrawerOpen"
        />

        <q-toolbar-title> Expertenverzeichnis</q-toolbar-title>

        <auth-links/>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="leftDrawerOpen" show-if-above bordered>
      <q-tabs
          animated
          swipeable
          vertical
          inline-label
          transition-prev="jump-up"
          transition-next="jump-up"
      >
        <q-route-tab v-for="route in displayRoutes"
                     :key="route.path"
                     :icon="route.meta?.icon"
                     :label="route.meta?.label"
                     :to="route.path"

        />
      </q-tabs>
    </q-drawer>

    <q-page-container>
        <router-view/>
    </q-page-container>
  </q-layout>
</template>
