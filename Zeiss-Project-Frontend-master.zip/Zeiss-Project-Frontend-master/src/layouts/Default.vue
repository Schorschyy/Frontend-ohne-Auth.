<script setup lang="ts"></script>

<template>
<!--  <q-page-container>-->
    <router-view/>
<!--  </q-page-container>-->
</template>
