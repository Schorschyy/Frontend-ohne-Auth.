<script setup lang="ts">
import SkillNameInput from "@/components/skill/SkillNameInput.vue";
import {useSkillTreeStore} from "@/scripts/stores/skillTree";
import {QForm} from "quasar";

const props = defineProps<{
  parentSkillId?: string
}>()
const emit = defineEmits(['added-skill'])

const skillStore = useSkillTreeStore()

const form = ref<QForm>()
const formData = reactive({name: ''})

const resetAction = () => {
  formData.name = ''
  form.value?.resetValidation();
}

const submitAction = () => {
  skillStore.addSkill({
    parentSkillId: props.parentSkillId ?? null,
    name: formData.name
  })
  emit('added-skill')
  resetAction()
}
onClickOutside(form, (_) => resetAction())
</script>


<template>
  <q-form
      ref="form"
      @submit="submitAction"
      @reset="resetAction"
      class="flex gap-1"
  >
    <skill-name-input
            v-model:name="formData.name"
            :parent-id="parentSkillId"
            label="Kategorie hinzufügen"
            :disable="skillStore.loading"
    />
    <q-btn
        dense
        flat
        type="submit"
        icon="add"
        :disable="skillStore.loading"
    />
  </q-form>
</template>