<script setup lang="ts">
import { Skill } from "@/scripts/types/datatypes";
import NewSkillForm from "@/components/skill/NewSkillForm.vue";
import SkillElement from "@/components/skill/Skill.vue";

defineProps<{
  skill: Skill;
}>();

const showChildren = ref(false);
</script>

<template>
  <q-item>
    <q-item-section
      clickable
      class="flex gap-2 !flex-row items-center !justify-start cursor-pointer"
      @click="showChildren = !showChildren"
    >
      <q-icon
        name="play_arrow"
        class="transition-transform rotate-0"
        :class="{ 'rotate-90': showChildren }"
      />

      <q-item-label>
        {{ skill.name }}
      </q-item-label>
    </q-item-section>
  </q-item>
  <q-list bordered v-if="showChildren" class="ml-12 mb-12">
    <SkillElement v-for="child in skill.childSkills" :skill="child" />
    <NewSkillForm :parent-skill-id="skill.id" class="ml-5" />
  </q-list>
</template>
