<script setup lang="ts">
import {SkillNode, useSkillTreeStore} from "@/scripts/stores/skillTree";
import SkillNameInput from "@/components/skill/SkillNameInput.vue";
import SkillDraggable from "@/components/skill/SkillDraggable.vue";

const props = defineProps<{
  node: SkillNode
}>()

const skillStore = useSkillTreeStore()

const formElement = ref<HTMLFormElement>()

const focused = ref(false)
const editingName = ref(props.node.meta.updated.name)

onClickOutside(formElement, (_) => onCloseForm())

const deleteAction = () => {
  skillStore.removeSkill(props.node.id)
}

const onOpenForm = () => {
  focused.value = true
  formElement.value?.reset()
}
const onCloseForm = () => {
  focused.value = false
  formElement.value?.submit()
}
</script>

<template>
  <skill-draggable :skill-id="node.id">
    <q-form
        ref="formElement"
        @click.stop="onOpenForm"
        class="h-10 flex items-center relative"
        @validation-success="node.meta.updated.name = editingName"
        @reset="editingName = node.meta.updated.name"
    >
      <template v-if="!focused">
        <div
            class="flex min-w-[3rem] bg-white rounded-full px-3 py-1"
        >
          <span class="text-weight-bold">{{ node.meta.updated.name }}</span>
        </div>
      </template>
      <template v-else>
        <div
            class="flex gap-2"
        >
          <skill-name-input v-model:name="editingName"/>

          <q-btn
              dense
              icon="delete"
              color="red"
              @click="deleteAction"
          />
        </div>
      </template>
    </q-form>
  </skill-draggable>
</template>