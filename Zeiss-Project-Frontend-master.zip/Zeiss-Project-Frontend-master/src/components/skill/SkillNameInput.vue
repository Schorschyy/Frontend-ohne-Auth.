<script setup lang="ts">
import {useSkillTreeStore} from "@/scripts/stores/skillTree";

const props = defineProps<{
  name: string,
  parentId?: string,
  label?: string,
}>()

const vName = useVModel(props, 'name')

const skills = useSkillTreeStore()
const uniqueName = (name: string) => {
  return !skills.findSkill(s => s.name === name)
}
</script>
<template>
  <q-input
      v-model="vName" :label="label ?? 'Kategorie Name'"
      lazy-rules
      :rules="[
          val => val && val.length > 0 || 'Please type something',
          val => uniqueName(val) || 'Not unique amongst same level skills'
      ]"
      dense
      square
      filled
  />
</template>

<style scoped>
.q-field {
  padding-bottom: 0;
}

.q-field__bottom {
  position: absolute;
  top: 0;
}
</style>
