<script setup lang="ts">
import {SkillNode, useSkillTreeStore} from "@/scripts/stores/skillTree";

const props = defineProps<{
  /**
   * falsy if root
   */
  skillId?: SkillNode["id"]
}>()
const skillStore = useSkillTreeStore()

const onDrag = (evt: DragEvent) => {
  // root not draggable
  if (props.skillId)
    skillStore.startMoveSkill(evt, props.skillId)
}
const onDrop = (evt: DragEvent) => {
  skillStore.endMoveSkill(evt, props.skillId ?? null)
}
</script>

<template>
  <div
      draggable="true"
      @dragstart="onDrag"
      @drop="onDrop"
      @dragover.prevent
      @dragenter.prevent
  >
    <slot/>
  </div>
</template>