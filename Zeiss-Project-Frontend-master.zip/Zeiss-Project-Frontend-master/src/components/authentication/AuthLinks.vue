<script setup lang="ts">
import {useAuthStore} from "@/scripts/stores/authentication";
import {startingLetters} from "@/scripts/util/stringUtil";

const auth = useAuthStore()
</script>

<template>
  <template v-if="auth.isLoggedIn">
    <q-btn flat>
      <q-avatar color="red" text-color="white" class="capitalize">
        {{ startingLetters(auth.account.name) }}
      </q-avatar>
      <q-space class="w-1" />
      <div>
        <p class="mb-0 leading-4 text-left">
          {{ auth.account.name }} <br/>
          <small>{{ auth.account.username }}</small>
        </p>
      </div>

      <!-- dropdown menu -->
      <q-menu anchor="bottom right" self="top right" auto-close>
        <q-item clickable @click="auth.signOut">
          <q-item-section>Logout</q-item-section>
          <q-item-section avatar><q-icon name="logout" /></q-item-section>
        </q-item>
      </q-menu>
    </q-btn>
  </template>
  <template v-else>
    <q-btn @click="auth.signIn">
      Login
    </q-btn>
  </template>
</template>
