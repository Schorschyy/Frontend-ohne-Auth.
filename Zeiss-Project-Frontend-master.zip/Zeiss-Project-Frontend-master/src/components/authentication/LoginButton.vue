<script setup lang="ts">
import {useAuthStore} from "@/scripts/stores/authentication";

const auth = useAuthStore()
</script>
<template>
  <q-btn
      color="primary"
      size="lg"
      icon-right="login"
      @click="auth.signIn">
    Login
  </q-btn>
</template>