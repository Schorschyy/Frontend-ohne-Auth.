<script setup lang="ts">
defineProps<{
  expert: Expert;
}>();
</script>

<template>
  <div class="py-2">
    <q-item>
      <q-item-section top avatar>
        <q-avatar size="75px" class="rounded-full bg-gray-100"> </q-avatar>
      </q-item-section>

      <q-item-section>
        <q-item-label>{{ expert.name }}</q-item-label>
        <p class="text-gray-500 text-sm">
          <q-item-label>Fähigkeiten:</q-item-label>
          <span caption v-for="skill in expert.skills" class="mr-2"> {{ skill.name }}</span>
        </p>
      </q-item-section>

      <q-item-section side top>
        <q-btn
          icon="mail"
          label="Kontaktieren"
          class="primary"
          style="width: 100%"
          v-slot:default
        />
      </q-item-section>
    </q-item>
  </div>
</template>
