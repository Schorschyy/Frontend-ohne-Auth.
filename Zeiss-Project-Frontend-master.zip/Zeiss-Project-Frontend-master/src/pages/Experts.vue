<script setup lang="ts">
import Expert from "@/components/expert.vue";
import {useQuery} from "@vue/apollo-composable";
import {GET_EXPERTS} from "@/scripts/services/backend/actions/expert";

const { result, error, loading, refetch } = useQuery(GET_EXPERTS)
</script>


<template>
  <q-page class="q-pa-md">
    <h4 class="mb-5">Experten</h4>
    <q-list bordered padding class="divide-y">
      <Expert
          v-for="(expert, key) in result?.experts.nodes"
          :key="key"
          :expert="expert"
          :id="key"
      />
    </q-list> 
  </q-page>
</template>