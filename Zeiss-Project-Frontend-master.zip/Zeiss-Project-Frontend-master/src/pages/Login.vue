<script setup lang="ts">
import LoginButton from "@/components/authentication/LoginButton.vue";
import {useAuthStore} from "@/scripts/stores/authentication";
import {useRouter} from "vue-router";

const auth = useAuthStore()
const router = useRouter()

watchEffect(() => {
  if (auth.isLoggedIn)
    router.push({name: 'default'})
})
</script>

<template>
  <main class="h-screen flex items-center justify-center">
    <login-button/>
  </main>
</template>
