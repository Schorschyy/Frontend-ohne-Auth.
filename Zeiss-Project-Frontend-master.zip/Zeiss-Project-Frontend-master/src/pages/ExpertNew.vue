<script setup lang="ts">

import {Expert} from "@/scripts/types/datatypes";
import {useMutation} from "@vue/apollo-composable";
import {useQuasar} from 'quasar'
import {NEW_EXPERT} from "@/scripts/services/graphQl/expert";

const $q = useQuasar()

const expertForm = reactive({name: '', email: null as string | null})

const {mutate: newExpertMutationCall, onDone, onError} = useMutation(NEW_EXPERT, () =>
    ({
      variables: {
        input: toRaw(expertForm)
      }
    })
)

onDone((results) => {
  $q.loading.hide();
  const expert = results.data.addExpert.expert as Expert
  $q.notify({type: 'positive', message: `Experte ${expert.name} hinzugefügt`, caption: `ID: ${expert.id}`})
})
onError((error) => {
  $q.loading.hide();
  $q.notify({type: 'negative', message: JSON.stringify(error)})
})

const submitAction = () => {
  $q.loading.show()
  newExpertMutationCall()
}
</script>

<template>
  <h4>Experte Hinzufügen</h4>
  <q-form class="max-w-[30rem] flex flex-col gap-2" @submit.prevent="ValidityState" @validation-success="submitAction">
    <q-input name="name" label="Name" v-model="expertForm.name" required/>
    <q-input name="email" label="Email" type="email" v-model="expertForm.email"/>
    <q-btn type="submit">Hinzufügen</q-btn>
  </q-form>
</template>
