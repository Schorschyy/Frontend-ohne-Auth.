<script setup lang="ts">
import {useSkillTreeStore} from "@/scripts/stores/skillTree";
import NewSkillForm from "@/components/skill/NewSkillForm.vue";
import SkillNode from "@/components/skill/SkillNode.vue";
import SkillDraggable from "@/components/skill/SkillDraggable.vue";
import {QTree} from "quasar";

const skillStore = useSkillTreeStore()

const tree = ref<QTree>()
</script>

<template>
  <q-page padding>
    <h4>Übersicht - Kompetenzen</h4>

    <q-separator spaced color="gray"/>

    <q-tree
        ref="tree"
        :nodes="[skillStore.skillTree]"
        node-key="constantId"
        default-expand-all
        @lazy-load="skillStore.loadSkillChildren"
    >
      <!-- root only containing form -->
      <template #header-root>
        <skill-draggable class="w-full h-5"/>
      </template>
      <template #body-root>
        <new-skill-form
            @added-skill="tree.setExpanded(undefined, true)"
        />
      </template>

      <template #default-header="{node}">
        <!-- relative for selection layer -->
        <skill-node :node="node" class="relative"/>
      </template>
      <template #default-body="{node}">
        <new-skill-form
            :parent-skill-id="node.id"
            @added-skill="tree.setExpanded(node.constantId, true)"
        />
      </template>
    </q-tree>

    <q-page-sticky
        expand
        position="bottom"
    >
      <div class="px-6 py-2 w-full flex justify-end gap-2 bg-transparent">
        <q-btn
            type="submit"
            label="Speichern"
            :loading="skillStore.loading"
            color="teal"
            @click="skillStore.saveChanges"
        >
          <template v-slot:loading>
            <q-spinner-facebook/>
          </template>
        </q-btn>
        <q-btn
            type="reset"
            :disable="skillStore.loading"
            label="Zurücksetzen"
            @click="skillStore.resetChanges"
        />
      </div>
    </q-page-sticky>
  </q-page>
</template>