<script setup lang="ts">
</script>
<template>
  <q-banner inline-actions class="text-white bg-red">
    <span class="font-bold text-lg">404</span> Page not found
    <template v-slot:action>
      <q-btn flat color="white" label="go back" @click="$router.go(-1)" />
    </template>
  </q-banner>
</template>