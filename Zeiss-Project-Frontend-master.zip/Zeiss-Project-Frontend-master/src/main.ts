import {createApp, provide, h} from "vue";
import {DefaultApolloClient} from "@vue/apollo-composable";
import {Notify, Quasar, Loading} from "quasar";
import {createPinia} from "pinia";
import App from "./App.vue";
import "./style.css";
import "quasar/src/css/index.sass";
import "@quasar/extras/material-icons/material-icons.css";
import router from "./scripts/services/router";
import apolloClient from "./scripts/services/backend/apollo";

const pinia = createPinia();

const app = createApp({
    setup() {
        provide(DefaultApolloClient, apolloClient);
    },

    render: () => h(App),
});
app.use(pinia);
app.use(router);
app.use(Quasar, {
    plugins: {
        Notify,
        Loading,
    },
    config: {
        notify: {
            /* look at QuasarConfOptions from the API card */
        },
        loading: {},
    },
});
// avoid sideeffects
router.isReady().then(() => {
    app.mount("#app");
})
