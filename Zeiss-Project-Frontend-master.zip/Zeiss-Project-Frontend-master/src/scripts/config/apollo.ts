export const uri = "http://localhost:5203/graphql";
