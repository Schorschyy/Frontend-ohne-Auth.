import {RouteRecordRaw} from "vue-router";
import {hook} from "@/scripts/services/router/util";
import {useAuthStore} from "../stores/authentication";

import UserLayout from "@/layouts/User.vue";
import DefaultLayout from "@/layouts/Default.vue";
import Error404Page from "@/pages/404.vue";
import LoginPage from "@/pages/Login.vue";
import SearchPage from "@/pages/Search.vue";
import SkillsPage from "@/pages/Skills.vue";

// extendable guard options
export enum GuardType {
    NONE,
    AUTH,
}

export type RouteMeta = Partial<{
    // text in tab
    label: string;
    // icon in tab
    icon: string;
    // if route gets listed in tab
    tab: boolean;
    guarded: GuardType;
}>;

export const routes: readonly RouteRecordRaw[] = [
    {
        path: "/",
        name: "authenticated",
        component: UserLayout,
        meta: {
            guarded: GuardType.AUTH,
        },
        children: [
            {
                path: '',
                name: 'default',
                redirect: _ => '/search',
            },
            {
                path: 'search',
                component: SearchPage,
                meta: <RouteMeta>{
                    label: "Suche",
                    tab: true,
                    icon: 'manage_search',
                }
            },
            {
                path: 'skills',
                name: 'skills',
                component: SkillsPage,
                meta: <RouteMeta>{
                    label: "Skills",
                    tab: true,
                    icon: 'account_tree',
                }
            },
            {
                path: ":pathMatch(.*)*",
                component: Error404Page,
            },
        ],
    },
    {
        path: "/",
        name: "no-auth",
        component: DefaultLayout,
        meta: {
            guarded: GuardType.NONE,
        },
        children: [
            {
                name: "login",
                path: "login",
                component: LoginPage,
            },
            {
                ...hook("auth", () => useAuthStore().signIn()),
            },
            {
                ...hook("logout", () => useAuthStore().signOut()),
            },
        ],
    },

];

export default routes;
