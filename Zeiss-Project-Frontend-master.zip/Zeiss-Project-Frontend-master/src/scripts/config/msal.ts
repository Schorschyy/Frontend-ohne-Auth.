import { Configuration, LogLevel } from "@azure/msal-browser";

export const msalConfig: Configuration = {
  auth: {
    clientId: "5220c5f7-ee48-428c-b51e-506b303d3e25",
    authority:
      "https://login.microsoftonline.com/15715ba7-4fd3-48e8-ba9d-a8574331c3fb/",
    redirectUri: "http://localhost:5173/auth",
    postLogoutRedirectUri: "http://localhost:5173/login",
  },
  cache: {
    cacheLocation: "localStorage", // This configures where your cache will be stored
    storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
  },
  system: {
    // for debug
    loggerOptions: {
      loggerCallback: (
        level: LogLevel,
        message: string,
        containsPii: boolean
      ) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            return;
          case LogLevel.Info:
            console.info(message);
            return;
          case LogLevel.Verbose:
            console.debug(message);
            return;
          case LogLevel.Warning:
            console.warn(message);
            return;
        }
      },
    },
  },
};

// scope to access backend to set token audience
export const scopes = ["api://8009ba12-6d4d-454d-8f59-db57d27f1eb3/general"];
