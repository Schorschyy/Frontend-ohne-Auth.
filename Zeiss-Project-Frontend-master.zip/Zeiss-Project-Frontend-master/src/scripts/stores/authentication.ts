import { defineStore } from "pinia";
import { useGlobalStore } from "@/scripts/stores/global";
import { IAccount } from "@/scripts/services/auth";

export const useAuthStore = defineStore("auth", () => {
  const authHandler = useGlobalStore().authHandler;

  let initialized = false;

  const account = ref<IAccount | undefined>();
  const isLoggedIn = computed<boolean>(() => !!account.value);
  const error = ref<string>();

  const initialize = () => {
    if (initialized) return;
    initialized = true;
    return authHandler
      .getAccount()
      .then((activeAccount) => (account.value = activeAccount))
  };

  const signIn = () =>
    authHandler
      .signIn()
      .then(async (loggedInAccount) => {
        account.value = loggedInAccount;
      })
      .catch((e) => {
        console.error(`error during authentication: ${e}`);
        error.value = e;
        throw e;
      });

  const signOut = () =>
    authHandler
      .signOut()
      .then(() => {
        account.value = undefined;
      })
      .catch((e) => {
        console.error(`error during logout: ${e}`);
        error.value = e;
        throw e;
      });

  return {
    initialize,
    isLoggedIn,
    account,
    error,
    signIn,
    signOut,
  };
});
