import {defineStore} from "pinia";
import {GET_SKILL_BY_PARENT, UPSERT_SKILLS} from "@/scripts/services/backend/actions/skill";
import {Skill} from "@/scripts/types/datatypes";
import {useWrappedLazyQuery, useWrappedMutation} from "@/scripts/util/compositables/apollo";
import {Action, Action as EditStatus} from "@/__generated__/graphql";
import {useQuasar} from "quasar";
import {waitForRef} from "@/scripts/util/compositables/reactiveUtil";
import {generateId} from "@/scripts/util/idUtil";
import {errorCollectionNotify} from "@/scripts/util/compositables/errorHandling";

type PartialSkill = Omit<Skill, 'childSkills' | 'parentSkill'>
export type SkillNode = PartialSkill & {
    constantId: Skill["id"],
    meta: {
        updated: Pick<Skill, 'name' | 'parentSkillId'>
        status: EditStatus
    },
    children: SkillNode[],
    lazy: true,
}

export const useSkillTreeStore = defineStore('skill-tree', () => {

    const $q = useQuasar()

    // state ---------------------------------------------------------------------------------------------

    const skillTree = reactive<{ children: SkillNode[], [key: string]: any }>({
        //quasar root node
        label: '',
        header: 'root',
        body: 'root',
        children: []
    })
    /**
     * id map of reactive nodes currently available
     */
    const lookup = new Map<SkillNode['id'], SkillNode>()


    // fetch ---------------------------------------------------------------------------------------------

    // const rootSkillQuery = useQuery(GET_SKILL_BY_PARENT, {parent: null})
    const skillQuery = useWrappedLazyQuery(GET_SKILL_BY_PARENT, {}, {
        onError: error => {
            $q.notify({
                type: 'negative',
                message: error.message,
            })
        }
    })


    const upsertSkillsMutation = useWrappedMutation(UPSERT_SKILLS, {
        onResult: _ => {
            $q.notify({
                type: 'positive',
                message: 'Änderungen an den Kompetenzen wurden erfolgreich gespeichert'
            })
        },
        onError: errorCollectionNotify
    })

    // init
    skillQuery.load(() => ({parent: null}), result => result.data.skills
        .map(s => toNode({parentSkillId: null, ...s}))
        .map(skill => upsertLookup(addSkillToParent(skill)))
    )

    const loadSkillChildren = async (
        {node, done, fail}: { node: SkillNode, done: (children: SkillNode[]) => void, fail: () => void }
    ) => {
        if (node.meta.status === Action.Create) return done(node.children)

        await waitForRef(skillQuery.loading, (loading) => !loading)

        skillQuery.load(
            () => ({parent: node.id}),
            result => {
                const children = result.data.skills
                    .map(s => toNode({parentSkillId: null, ...s}))
                    .map(skill => addSkillToParent(skill))
                children.forEach(skill => upsertLookup(skill))
                done(children)
            },
            _ => fail()
        )
    }

    const saveChanges = () => {
        const toUpdate: SkillNode[] = []

        for (let node of lookup.values()) {
            switch (node.meta.status) {
                case EditStatus.Delete:
                case EditStatus.Create:
                    toUpdate.push(node);
                    break;
                case EditStatus.Update:
                    if (isEdited(node))
                        toUpdate.push(node)
                    break
            }
        }

        const toUpdateClean = toUpdate.map(n => ({
            referenceId: n.id,
            name: n.meta.updated.name,
            parentSkillReferenceId: n.meta.updated.parentSkillId,
            status: n.meta.status,
        }))

        upsertSkillsMutation.mutate({skills: toUpdateClean}, undefined, result => {
            // remove deleted from to update
            toUpdate
                .filter(s => s.meta.status === Action.Delete)
                .forEach(rm => lookup.delete(rm.id))

            // created and updated from reference id to entity id
            result?.upsertSkills.skillUpdateResult?.forEach(update => {
                const skill = lookup.get(update.referenceId)!
                skill.id = update.id
                skill.name = update.name
                skill.parentSkillId = update.parentSkillId ?? null
                skill.meta = {
                    status: Action.Update,
                    updated: {
                        name: update.name,
                        parentSkillId: update.parentSkillId ?? null,
                    }
                }

                lookup.delete(update.referenceId)
                lookup.set(skill.id, skill)
            })
        })
    }

    const resetChanges = () => {
        const removedIds = new Set<SkillNode["id"]>()

        for (let skillId of lookup.keys()) {
            const node = lookup.get(skillId)!

            switch (node.meta.status) {
                case EditStatus.Create:
                    removedIds.add(skillId)
                    break;
                case EditStatus.Delete:
                case EditStatus.Update:
                    // reset to fetched
                    node.meta = {
                        status: EditStatus.Update,
                        updated: {
                            name: node.name,
                            parentSkillId: node.parentSkillId
                        }
                    }
                    break;
            }
        }
        removedIds.forEach(removedId => {
            lookup.delete(removedId)
        })

        // remove from tree
        for (let node of lookup.values()) {
            node.children = node.children.filter(n => !removedIds.has(n.id))
        }
        skillTree.children = skillTree.children.filter(n => !removedIds.has(n.id))
    }

    // build ---------------------------------------------------------------------------------------------

    /**
     * if skill properties have changed from initial
     */
    const isEdited = (skill: SkillNode) => {
        return skill.name !== skill.meta.updated.name
            || skill.parentSkillId !== skill.meta.updated.parentSkillId
    }

    const toNode = (skill: PartialSkill, status = EditStatus.Update): SkillNode => ({
        constantId: skill.id,
        id: skill.id,
        name: skill.name,
        parentSkillId: skill.parentSkillId,
        meta: {
            updated: {
                name: skill.name,
                parentSkillId: skill.parentSkillId,
            },
            status,
        },
        children: [],
        lazy: true,
    })

    const upsertLookup = (...nodes: SkillNode[]) => {
        nodes.forEach(n => lookup.set(n.id, n))
    }

    /**
     * adds skill to tree
     */
    const addSkillToParent = (skill: SkillNode): SkillNode => {
        let children: SkillNode[];
        const parentId = skill.meta.updated.parentSkillId;
        if (parentId) {
            const parentNode = lookup.get(parentId)!
            children = parentNode.children
        } else {
            children = skillTree.children
        }
        // save proxy for reactivity
        const iNode = children.push(skill) - 1;
        return children[iNode]
    }

    /**
     * removes skill from tree
     */
    const removeSkillFromParent = (skill: SkillNode) => {
        const skillId = skill.id
        const parentId = skill.meta.updated.parentSkillId;
        if (parentId) {
            const parent = lookup.get(parentId)!
            parent.children = parent.children.filter(n => (n.id !== skillId))
        } else {
            skillTree.children = skillTree.children.filter(n => (n.id !== skillId))
        }
    }

    /**
     * moves given skill to new parent
     * updates tree
     */
    const swapSkillParent = (skill: SkillNode, newParentId: SkillNode["id"] | null) => {
        removeSkillFromParent(skill)
        skill.meta.updated.parentSkillId = newParentId
        addSkillToParent(skill)
    }

    /**
     * add skill data to tree
     */
    const addSkill = (skill: Pick<SkillNode, 'parentSkillId' | 'name'>) => {
        const node = toNode({...skill, id: generateId()})
        node.meta.status = EditStatus.Create
        upsertLookup(addSkillToParent(node))
    }

    /**
     * removes skill and all its descendants from tree
     */
    const removeSkill = (removeSkillId: SkillNode["id"]) => {
        const removeNode = lookup.get(removeSkillId)!
        if (!removeNode) return

        // remove children (new -> destroy, updated = moved into new -> delete)
        // all none connected existing entities in db will cascade delete
        const removedStack = [removeNode]
        while (removedStack.length > 0) {
            const removeNode = removedStack.pop()!
            // remove from tree
            removeSkillFromParent(removeNode)

            // soft delete / destroy
            if (removeNode.meta.status === EditStatus.Create) {
                lookup.delete(removeSkillId)
            } else {
                removeNode.meta.status = EditStatus.Delete
                removeNode.meta.updated.parentSkillId = null
            }

            removeNode.children.forEach(rm => removedStack.push(rm))
        }
    }

    const skillModeTransferKey = 'skill-id'
    const startMoveSkill = (evt: DragEvent, skillId: SkillNode["id"]) => {
        if (evt.dataTransfer) {
            evt.dataTransfer.dropEffect = 'move';
            evt.dataTransfer.effectAllowed = 'move';
            evt.dataTransfer.setData(skillModeTransferKey, skillId);
        }
    }
    const endMoveSkill = (evt: DragEvent, toSkillId: SkillNode["id"] | null) => {
        const movSkillId = evt.dataTransfer?.getData(skillModeTransferKey);
        if (!movSkillId) return

        const movSkill = lookup.get(movSkillId)!
        swapSkillParent(movSkill, toSkillId);
    }

    //----------------------------------------------------------------------------------------------------

    const loading = computed(() => {
        return skillQuery.loading.value || upsertSkillsMutation.loading.value
    })

    const findSkill = (predicate: (skill: Readonly<SkillNode>) => boolean) => {
        for (let skill of lookup.values()) {
            if (predicate(skill))
                return skill
        }
    }


    return {
        skillTree,
        addSkill, removeSkill,
        startMoveSkill, endMoveSkill,
        saveChanges, resetChanges,
        loading, loadSkillChildren,
        findSkill
    }
})