import { defineStore } from "pinia";
import { msalFacade } from "@/scripts/services/auth/msalFacade";
import {mockFacade} from "@/scripts/services/auth/MockFacade";

/*
 * cant get pinia global custom properties using setup stores
 * => global store used as dependency injection store
 * + pinia store already supports ssr
 */
export const useGlobalStore = defineStore("global", () => {
  const authHandler = mockFacade(); //msalFacade();

  return {
    authHandler,
  };
});
