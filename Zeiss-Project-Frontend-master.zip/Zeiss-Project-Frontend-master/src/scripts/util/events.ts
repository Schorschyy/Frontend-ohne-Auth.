const addListener = <T extends (...params: any) => any>(listeners: T[], listener: T) => {
    listeners.push(listener)
}
const removeListener = <T extends (...params: any) => any>(listeners: T[], listener: T) => {
    const i = listeners.findIndex(l => l === listener)
    if (i < 0) return false
    listeners.splice(i, 1)
    return true
}

/**
 * @param eventCallback a function registering the callback for event
 */
export const createEvent = <T extends (...params: any) => any>(
    eventCallback: (onEvent: T) => void
) => {
    const onEventListeners = [] as T[]

    eventCallback(<T>((...params) => {
        onEventListeners.forEach(listener => {
            listener(...params)
        })
    }))

    return {
        addListener: (listener: T) => {
            addListener(onEventListeners, listener)
            return {off: () => removeListener(onEventListeners, listener)}
        },
        addListenerOnce: (listenerOnce: T) => {
            const listener = <T>((...params) => {
                removeListener(onEventListeners, listener)
                // @ts-ignore
                listenerOnce(...params)
            })
            addListener(onEventListeners, listener)
            return {off: () => removeListener(onEventListeners, listener)}
        },
    }
}