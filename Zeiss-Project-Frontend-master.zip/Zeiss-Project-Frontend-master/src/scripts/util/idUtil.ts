const uniqueNumber = () => {
    const timestamp = new Date().getTime();
    const randomValue = Math.floor(Math.random() * 1e6);
    return timestamp * 1e6 + randomValue;
};


export const generateId = () => Date.now().toString(36) + Math.random().toString(36).substr(2);