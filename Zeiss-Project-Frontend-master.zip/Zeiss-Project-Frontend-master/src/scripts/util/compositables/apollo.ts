import {DocumentParameter, OptionsParameter, VariablesParameter} from "@vue/apollo-composable/dist/useQuery";
import {
    ApolloQueryResult,
    FetchResult,
    MutationOptions,
    OperationVariables,
    ServerError,
    ServerParseError,
    TypedDocumentNode
} from '@apollo/client/core';
import {useLazyQuery, useMutation, useQuery} from "@vue/apollo-composable";
import {createEvent} from "@/scripts/util/events";
import {ApolloError} from "@apollo/client";
import {Error as MutationError} from "@/__generated__/graphql"
import {GraphQLError} from "graphql/error";
import {MutateOverrideOptions} from "@vue/apollo-composable/dist/useMutation";

export type TypedDocumentResult<TDocumentNode> = TDocumentNode extends DocumentParameter<infer TResult, infer TVariables> ? TResult : never
export type TypedDocumentVariables<TDocumentNode> = TDocumentNode extends DocumentParameter<infer TResult, infer TVariables> ? TVariables : never

/**
 * wrapped lazy query
 * variables provided on load call
 * events can be intercepted multiple times and on call
 */
export const useWrappedLazyQuery = <TResult, TVariables extends OperationVariables>(
    document: TypedDocumentNode<TResult, TVariables>,
    initialVariables?: VariablesParameter<TVariables>,
    options?: OptionsParameter<TResult, TVariables> & {
        onResult?: (results: ApolloQueryResult<TResult>) => void,
        onError?: (error: ApolloError) => void
    }
) => {
    const query = useLazyQuery(document, initialVariables, options)

    type Results = Parameters<Parameters<typeof query.onResult>[0]>
    type Errors = Parameters<Parameters<typeof query.onError>[0]>

    const resultEvent = createEvent(query.onResult)
    const errorEvent = createEvent(query.onError)

    if (options?.onResult)
        resultEvent.addListener(options.onResult)
    if (options?.onError)
        errorEvent.addListener(options.onError)

    return {
        ...query,
        load: (
            variables?: () => TVariables,
            onResult?: (...params: Results) => void,
            onError?: (...params: Errors) => void
        ) => {
            if (variables)
                query.variables.value = variables()

            if (onResult) resultEvent.addListenerOnce(onResult)
            if (onError) errorEvent.addListenerOnce(onError)

            return query.load()
        },
        onResult: resultEvent.addListener,
        onError: errorEvent.addListener,
    }
}


/**
 * wrapped query
 * variables can be provided on refetch call
 * events can be intercepted multiple times and on call
 */
export const useWrappedQuery = <TResult, TVariables extends OperationVariables>(
    document: TypedDocumentNode<TResult, TVariables>,
    initialVariables: VariablesParameter<TVariables>,
    options: OptionsParameter<TResult, TVariables>
) => {
    const query = useQuery(document, initialVariables, options)

    type Results = Parameters<Parameters<typeof query.onResult>[0]>
    type Errors = Parameters<Parameters<typeof query.onError>[0]>

    const resultEvent = createEvent(query.onResult)
    const errorEvent = createEvent(query.onError)

    return {
        ...query,
        refetch: (
            variables?: () => TVariables,
            onResult?: (...params: Results) => void,
            onError?: (...params: Errors) => void
        ) => {
            if (variables)
                query.variables.value = variables()

            if (onResult) resultEvent.addListenerOnce(onResult)
            if (onError) errorEvent.addListenerOnce(onError)

            return query.refetch()
        },
        onResult: resultEvent.addListener,
        onError: errorEvent.addListener,
    }
}

// type for most common errors with ability to differentiate between
export type GeneralError = {
    type: 'apollo',
    error: ApolloError
} | {
    type: 'mutation',
    errors: MutationError[]
} | {
    type: 'grapql',
    errors: readonly GraphQLError[]
}

/**
 * wrapped mutation
 * variables provided on mutate call
 * events can be intercepted multiple times and on call
 * `onResult` and `onError` follows mutation conventions
 */
export const useWrappedMutation = <TResult = any, TVariables extends OperationVariables = OperationVariables>(
    document: TypedDocumentNode<TResult, TVariables>,
    options?: Omit<MutationOptions<TResult, TVariables>, 'mutation'> & {
        onResult?: (data: FetchResult<TResult>["data"]) => void,
        onError?: (errorsCollection: {
            error: GeneralError | undefined,
            clientErrors: readonly  Error[] | undefined,
            networkError: Error | ServerParseError | ServerError | undefined
        }) => void
    }
) => {
    const mutation = useMutation(document, options)

    const combinedErrors = ref<GeneralError>()

    let combinedErrorListener: (errors: {
        error: GeneralError | undefined,
        clientErrors: readonly  Error[] | undefined,
        networkError: Error | ServerParseError | ServerError | undefined
    }) => void;

    mutation.onError(({graphQLErrors, clientErrors, networkError}) => {
        if (graphQLErrors) {
            combinedErrors.value = {
                type: 'grapql',
                errors: graphQLErrors
            }
        }
        // display unexpected errors
        if (clientErrors)
            console.error(clientErrors)
        if (networkError)
            console.error(networkError)
        if (combinedErrorListener)
            combinedErrorListener({error: combinedErrors.value, clientErrors, networkError: networkError ?? undefined})
    })

    let resultListener: (data: FetchResult<TResult>["data"]) => void;
    mutation.onDone(({data, errors}) => {
        if (errors) {
            combinedErrors.value = {
                type: 'grapql',
                errors,
            }
            if (combinedErrorListener)
                combinedErrorListener({error: combinedErrors.value, clientErrors: undefined, networkError: undefined})
            return
        }
        const returnedErrors = [] as MutationError[]
        if (data) {
            const results = data as { [key: string]: { [key: string]: any } }
            Object.values(results).forEach(requestResult =>
                Object.keys(requestResult).forEach(key => {
                    if (key !== 'errors') return
                    (requestResult[key] as MutationError[])
                        .forEach(e => returnedErrors.push(e))
                })
            )
        }
        if (returnedErrors.length > 0) {
            combinedErrors.value = {
                type: 'mutation',
                errors: returnedErrors
            }
            if (combinedErrorListener)
                combinedErrorListener({error: combinedErrors.value, clientErrors: undefined, networkError: undefined})
            return;
        }

        if (resultListener)
            resultListener(data)
    })

    const resultEvent = createEvent(listener => {
        resultListener = listener
    })
    const errorEvent = createEvent(listener => {
        combinedErrorListener = listener
    })

    if (options?.onResult)
        resultEvent.addListener(options.onResult)
    if (options?.onError)
        errorEvent.addListener(options.onError)

    return {
        ...mutation,
        mutate: (
            variables?: TVariables | null,
            overrideOptions?: MutateOverrideOptions<TResult>,
            onResult?: typeof resultListener,
            onError?: typeof combinedErrorListener,
        ) => {
            if (onResult) resultEvent.addListenerOnce(onResult)
            if (onError) errorEvent.addListenerOnce(onError)

            return mutation.mutate(variables, overrideOptions)
        },
        onResult: resultEvent.addListener,
        onError: errorEvent.addListener,
    }
}