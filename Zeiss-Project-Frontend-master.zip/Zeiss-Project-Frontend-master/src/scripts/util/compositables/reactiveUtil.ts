import {Ref} from "vue";

/**
 * @param ref to watch
 * @param predicate if predicate returns true wait resolves
 */
export const waitForRef = <T>(ref: Ref<T>, predicate: (value: T) => boolean) => {
    return new Promise((resolve: (value?: unknown) => void) => {
        if (predicate(ref.value)) return resolve()
        const stopWatcher = watch(ref, (newValue) => {
            if (predicate(newValue)) {
                resolve()
                stopWatcher()
            }
        })
    })
}
