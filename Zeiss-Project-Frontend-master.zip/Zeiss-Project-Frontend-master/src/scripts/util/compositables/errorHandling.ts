import {ServerError, ServerParseError} from "@apollo/client/core";
import {GeneralError} from "@/scripts/util/compositables/apollo";
import {Notify} from "quasar";

export const errorCollectionNotify: (errorsCollection: {
    error: GeneralError | undefined,
    clientErrors: readonly  Error[] | undefined,
    networkError: Error | ServerParseError | ServerError | undefined
}) => void = errorCollection => {

    const messages: string[] = []

    if (errorCollection.networkError) {
        messages.push(errorCollection.networkError.message)
    }

    if (errorCollection.clientErrors) {
        errorCollection.clientErrors.forEach(e => messages.push(e.message))
    }

    if (errorCollection.error) {
        const error = errorCollection.error
        switch (error.type) {
            case "mutation":
            case "grapql":
                error.errors.forEach(e => {
                    messages.push(e.message)
                })
                break
            case "apollo":
                messages.push(error.error.message)
        }
    }

    messages.forEach(message => {
        Notify.create({
            type: 'negative',
            message,
        })
    })
}