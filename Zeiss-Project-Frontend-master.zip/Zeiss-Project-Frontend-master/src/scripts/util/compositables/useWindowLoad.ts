export const useWindowLoad = (callback : () => void) => {
    const onLoad = () => {
        if (typeof callback === 'function') {
            callback()
        }
    }

    onMounted(() => window.addistener('load', onLoad))
    onUnmounted(() => window.removeEventListener('load', onLoad))
}