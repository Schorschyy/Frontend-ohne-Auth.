export type Skill = {
    id: string,
    name: string,
    parentSkillId: string | null,
    parentSkill?: Skill,
    childSkills?: Skill[]
}


export type Expert = {
    id: string,
    name: string,
    email: string | null,
    headExpertId: string | null,
    expert?: Expert
    teamMembers?: Expert[]
    skills: Skill[]
}