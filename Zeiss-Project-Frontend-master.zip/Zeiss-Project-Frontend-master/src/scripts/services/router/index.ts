import {createRouter, createWebHistory} from "vue-router";

import routes, {GuardType} from "@/scripts/config/router";
import {useAuthStore} from "@/scripts/stores/authentication";

// create router
const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes,
});


// set up auth and guard routes
router.beforeEach(async (to, from, next) => {
    const auth = useAuthStore();
    // load from cache
    await auth.initialize();

    const requireAuthenticated = to.matched
        .map((match) => match.meta.guarded)
        .filter(guarded => guarded !== undefined)
        .reduce(
            (isGuarded, current) => isGuarded || current === GuardType.AUTH,
            false
        );

    if (requireAuthenticated) {
        // authorised
        if (auth.isLoggedIn) return next();

        // unauthorised
        try {
            await auth.signIn();
        } catch (err) {
        }

        if (auth.isLoggedIn) return next();
        else return next({name: "login"});
    }

    // unguarded
    next();
});

export default router;
