import type {RouteRecordRaw} from "vue-router";

/**
 * Create hook route
 */
export function hook(path: string, callback: Function): RouteRecordRaw {
    return {
        path,
        component: {render: () => null},
        beforeEnter: async (to, from, next) => {
            const result = await callback();
            result ? next() : next(false);
        },
    };
}

export function getFlattRoutes(routes: readonly RouteRecordRaw[], parentPath : string = '') {
    const allRoutes: Omit<RouteRecordRaw, 'children'>[] = [];

    routes.forEach(route => {
        const currentPath = `${parentPath}${route.path}`;
        allRoutes.push({...route, path: currentPath});

        if (route.children) {
            const childRoutes = getFlattRoutes(route.children, currentPath);
            allRoutes.push(...childRoutes);
        }
    });

    return allRoutes;
}