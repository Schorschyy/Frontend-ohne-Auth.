import {graphql} from "@/__generated__";

export const GET_SKILLS =
graphql(`#graphql
query GetSkills{
    skills{
        name
        id
        parentSkillId
    }
}`);

export const GET_SKILL_BY_PARENT =
graphql(`#graphql
query GetSkill($parent : ID){
    skills(where: { parentSkillId: {eq: $parent}}) {
        id
        name
        parentSkillId
    }
}
`);

export const UPSERT_SKILLS =
graphql(`#graphql
mutation UpsertSkills($skills : [SkillUpdateInput!]!){
    upsertSkills(input: {skills: $skills}) {
        skillUpdateResult {
            referenceId
            id
            name
            parentSkillId
        }
        errors {
            code: __typename
            ... on Error {
                message
            }
        }
    }
}
`)