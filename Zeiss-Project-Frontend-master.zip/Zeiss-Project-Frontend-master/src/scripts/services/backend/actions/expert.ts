import {graphql} from "@/__generated__";

export const GET_ME =
    graphql(`#graphql
        query GetMe {
            me {
                id
                name
            }
        }
    `)

export const GET_EXPERTS =
    graphql(`#graphql
    query GetExperts {
        experts {
            nodes {
                id
                name
                skills {
                    id
                    name
                }
            }
            edges {
                cursor
            }
        }
    }`)