import {
  ApolloClient,
  createHttpLink,
  from,
  InMemoryCache,
  ServerParseError,
} from "@apollo/client/core";
import { setContext } from "@apollo/client/link/context";
import { onError } from "@apollo/client/link/error";
import { uri } from "@/scripts/config/apollo";
import { useGlobalStore } from "@/scripts/stores/global";

// Cache implementation
const cache = new InMemoryCache();

// request flow through links ------------------------------------------------------------------------

// HTTP connection to the API
const httpLink = createHttpLink({
  // You should use an absolute URL here
  uri,
});

// auth headers for api
let authHeadersCached: { [key: string]: string } | undefined;
const authHeadersLink = setContext((_, { headers: prevHeaders }) => {
  const combineHeaders = (authHeaders: { [key: string]: string }) => ({
    headers: { ...authHeaders, ...prevHeaders },
  });

  // if you have a cached value, return it immediately
  if (authHeadersCached) return combineHeaders(authHeadersCached);

  const authHandler = useGlobalStore().authHandler;

  return authHandler
    .getAuthHeaders()
    .then((headers) => (authHeadersCached = headers))
    .then(combineHeaders);
});

// refresh headers on authentication error
const resetToken = onError(({ networkError }) => {
  // on auth fail, credentials not valid, get new on next request
  if (networkError && (networkError as ServerParseError).statusCode === 401) {
    authHeadersCached = undefined;
  }
});
const authFlowLink = authHeadersLink.concat(resetToken);

// Create the apollo client
const apolloClient = new ApolloClient({
  cache,
  link: from([authFlowLink, httpLink]),
});

export default apolloClient;
