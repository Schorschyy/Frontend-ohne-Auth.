import {IAuthenticationFacade} from "@/scripts/services/auth/index";

export const mockFacade = (): IAuthenticationFacade => {
    return {
        signIn: async () => undefined,
        signOut: async () => {
        },
        getAccount: async () => ({
            name: "Mock User",
            username: "temp for testing"
        }),
        getAuthHeaders: async () => ({})
    }
}