import {
  AccountInfo,
  EndSessionPopupRequest,
  InteractionRequiredAuthError,
  PopupRequest,
  PublicClientApplication,
  SilentRequest,
  NavigationClient,
} from "@azure/msal-browser";
import { IAuthenticationFacade } from ".";
import { msalConfig, scopes } from "@/scripts/config/msal";
import type { NavigationOptions } from "@azure/msal-browser";
import type { Router } from "vue-router";
import router from "@/scripts/services/router";

/**
 * Override MSAL route navigation
 */
export class VueNavigationClient extends NavigationClient {
  private router: Router;

  constructor(router: Router) {
    super();
    this.router = router;
  }

  /**
   * Only called during redirects
   */
  navigateExternal(url: string, options: NavigationOptions): Promise<boolean> {
    return super.navigateExternal(url, options);
  }

  /**
   * Only called during popup completion
   */
  async navigateInternal(
    url: string,
    options: NavigationOptions
  ): Promise<boolean> {
    const path = url.replace(location.origin, "");
    options.noHistory
      ? await this.router.replace(path)
      : await this.router.push(path);
    return true;
  }
}

export const msalFacade = (): IAuthenticationFacade => {
  let initialized = false;
  const msalInstance = new PublicClientApplication(msalConfig);

  type OptionalAccount = AccountInfo | undefined;
  let activeAccount: OptionalAccount = undefined;

  // util ----------------------------------------------------------------------------------------------

  /**
   * Set active account
   */
  const setAccount = (account: OptionalAccount): OptionalAccount => {
    activeAccount = account;
    msalInstance.setActiveAccount(account ?? null);
    return account;
  };

  /**
   * Escape hatch when msal gets stuck
   */
  const reset = () => {
    sessionStorage.clear();
  };

  const prependInit = <T extends (...args: any[]) => Promise<any>>(fn: T): T =>
    <T>((...args) => initIfNeeded().then(() => fn(args)));

  // fuctionality --------------------------------------------------------------------------------------

  const initIfNeeded = async () => {
    if (initialized) return;
    initialized = true;

    // hook MSAL into router
    const client = new VueNavigationClient(router);

    // start msal
    await msalInstance.handleRedirectPromise();

    // hook into application router
    msalInstance.setNavigationClient(client);

    // grab and set account if in session
    const accounts = msalInstance.getAllAccounts();
    if (accounts?.length) setAccount(accounts[0]);
  };

  const signIn = async (): Promise<OptionalAccount> => {
    /**
     * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/request-response-object.md#request
     */
    return await msalInstance
      .loginPopup({ scopes })
      .then((response) => {
        if (!!response && response.account) return setAccount(response.account);
      })
      .catch((error) => {
        console.error(error);
        // if we get stuck, clear session and attempt to log in again
        if (error.errorCode === "interaction_in_progress") {
          reset();
          return signIn();
        }
        throw error;
      });
  };

  const signOut = async (): Promise<void> => {
    /**
     * You can pass a custom request object below. This will override the initial configuration. For more information, visit:
     * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/request-response-object.md#request
     */
    const logoutRequest: EndSessionPopupRequest = {
      account: activeAccount ?? null,
    };

    return msalInstance.logoutPopup(logoutRequest);
  };

  const getAccessToken = async (silent: boolean = false): Promise<string> => {
    const request: SilentRequest & PopupRequest = {
      scopes,
    };

    try {
      const tokenResponse = await msalInstance.acquireTokenSilent(request);
      return tokenResponse.accessToken;
    } catch (error) {
      if (!silent && error instanceof InteractionRequiredAuthError) {
        const tokenResponse = await msalInstance.acquireTokenPopup(request);
        return tokenResponse.accessToken;
      }
      throw error;
    }
  };

  const getAuthHeaders = async (): Promise<{ [key: string]: string }> => {
    if (!activeAccount) return {};

    const token = await getAccessToken(false);
    return {
      authorization: `Bearer ${token}`,
    };
  };

  return {
    signIn: prependInit(signIn),
    signOut: prependInit(signOut),
    getAuthHeaders: prependInit(getAuthHeaders),
    getAccount: prependInit(async () => activeAccount),
  };
};
