export interface IAuthenticationFacade {
    getAccount: () => Promise<IAccount | undefined>;
    signIn: () => Promise<IAccount | undefined>;
    signOut: () => Promise<void>;
    getAuthHeaders: () => Promise<{ [key: string]: string }>;
}

export interface IAccount {
    name: string,
    username: string;
}
